package com.nagarro.Calculator;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello Nagarro!" );
        calculate cal = new calculate();
        int a =10;
        int b =20;
        int ans = cal.add(a, b);
        System.out.println("The sum is - "+ ans);
    }
}
