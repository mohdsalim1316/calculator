package com.nagarro.Calculator;

public class calculate {
	public int add(int a,int b) {
		return a+b;
	}
}
