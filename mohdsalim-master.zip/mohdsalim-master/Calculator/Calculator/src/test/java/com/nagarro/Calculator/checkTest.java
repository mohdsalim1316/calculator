package com.nagarro.Calculator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.junit.Test;

public class checkTest {
calculate cal = new calculate();
    
    @Test
    public void PositiveAddition() {
    	int a=15;
		int b=15;
		int add;
		add= cal.add(a, b);
	
		assertEquals(30, add);
    }
    
    @Test
    public void NegativeAddition() {
    	int a=15;
		int b=15;
		int add;
		add= cal.add(a, b);
	
		assertNotEquals(add, 20);
    }
}
