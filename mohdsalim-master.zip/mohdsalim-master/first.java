package jenkins;

public class first {

	public static void main(String[] args) {
		
		
		System.out.println("HELLO WORLD!");
		
	}

}
