package com.nagarro.assignment1.test.service;



import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.nagarro.assignment1.service.CalculatorService;

public class CalculatorTest {
	CalculatorService cs = new CalculatorService();
	
	@Test
	public void testAddition() {
		
		int a=15;
		int b=15;
		int add= cs.addNumber(a, b);
	    assertEquals(30, add);		
	}
	
	@Test
	public void testSubtraction() {
		
		int a=15;
		int b=15;
		int sub= cs.subtractNumber(a, b);	
		assertEquals(0,sub);
	}
	
	@Test
	public void testMultiplication() {
		
		int a=15;
		int b=15;
		int mul= cs.multiplyNumber(a, b);	
		assertEquals(225,mul);
	}
	
	@Test
	public void testDivide() {
		
		int a=15;
		int b=15;
		int div= cs.divideNumber(a, b);
		
		assertEquals(1,div);
	}
	
}
