package com.nagarro.assignment1.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nagarro.assignment1.service.CalculatorService;

@Controller
public class CalculatorController {
	
	@Autowired
	CalculatorService service;
	
	@RequestMapping("/calculate")
	public ModelAndView calculator(HttpServletRequest request,HttpServletResponse response) {
		
		int x = Integer.parseInt(request.getParameter("num1"));
		int y = Integer.parseInt(request.getParameter("num2"));
		
		int add= service.addNumber(x,y);
		int subtract= service.subtractNumber(x,y);
		int multiply= service.multiplyNumber(x,y);
		int divide= service.divideNumber(x,y);
		
		
		ModelAndView m= new ModelAndView();
		m.addObject("add", add);
		m.addObject("sub", subtract);
		m.addObject("mul", multiply);
		m.addObject("div", divide);
		
		m.setViewName("display");
		return m;
	}

}
