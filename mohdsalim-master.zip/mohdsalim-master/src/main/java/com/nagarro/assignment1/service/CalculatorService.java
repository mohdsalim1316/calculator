package com.nagarro.assignment1.service;

import org.springframework.stereotype.Service;

@Service
public class CalculatorService {
	public int addNumber(int a,int b) {
		return a+b;
	}
	
	public int subtractNumber(int a,int b) {
		return a-b;
	}
	
	public int multiplyNumber(int a,int b) {
		return a*b;
	}
	
	public int divideNumber(int a,int b) {
		return a/b;
	}
}
